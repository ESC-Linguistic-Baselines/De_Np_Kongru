# Changelog

## 1.1 - 2018-08-24

merlin-annis, merlin-exmaralda, merlin-paula, merlin-solr, merlin-text:

- corrected garbled TH1s for German texts 1061_0120358 and 1061_0120440

merlin-docs, merlin-metadata, merlin-tasks:

- version bump without changes

merlin-relannis:

- deprecated, use merlin-annis instead

## 1.0 - 2014-12-31

Initial release of MERLIN corpus available through the MERLIN platform:
http://merlin-platform.eu
